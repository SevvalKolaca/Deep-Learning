<?php
if (isset($_POST["submit"])) {
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if ($check !== false) {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            // File is uploaded successfully, now send it to Flask server
            $url = 'http://127.0.0.1:5000/upload'; // Replace with your Flask server URL
            $cFile = curl_file_create(realpath($target_file));
            $post = ['file' => $cFile];


            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            // Initiate the request asynchronously
            $mh = curl_multi_init();
            curl_multi_add_handle($mh, $ch);

            do {
                curl_multi_exec($mh, $running);
            } while ($running > 0);

            // Get the response
            $response = curl_multi_getcontent($ch);
            curl_multi_remove_handle($mh, $ch);
            curl_multi_close($mh);

            // Display the Flask server response
            echo "Server response: " . $response;
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    } else {
        echo "File is not an image.";
    }
} else {
    echo "No file uploaded.";
}
